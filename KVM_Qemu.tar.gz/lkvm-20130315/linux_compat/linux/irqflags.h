#ifndef _LINUX_IRQFLAGS_H
#define	_LINUX_IRQFLAGS_H

#include <asm/irqflags.h>

#endif
