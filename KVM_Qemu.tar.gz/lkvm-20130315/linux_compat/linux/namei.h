#ifndef _LINUX_NAMEI_H
#define _LINUX_NAMEI_H

#include <linux/dcache.h>

struct vfsmount;

struct path {
	struct vfsmount	*mnt;
	struct dentry	*dentry;
};

#endif
