#ifndef _LINUX_HIGHMEM_H
#define _LINUX_HIGHMEM_H

#include <linux/mm.h>
#include <asm/highmem.h>

#endif
