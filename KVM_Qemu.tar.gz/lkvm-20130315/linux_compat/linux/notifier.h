#ifndef _LINUX_NOTIFIER_H
#define _LINUX_NOTIFIER_H

struct notifier_block {
	int (*notifier_call)(struct notifier_block *, unsigned long, void *);
	struct notifier_block *next;
	int priority;
};

#define	NOTIFY_OK	1

#define	SYS_DOWN	1
#define	SYS_RESTART	SYS_DOWN

#define	CPU_ONLINE		2
#define	CPU_UP_CANCELED		4
#define	CPU_DOWN_PREPARE	5

#endif
