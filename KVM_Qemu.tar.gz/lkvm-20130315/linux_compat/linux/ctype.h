/*
 * Copyright (c) 2007 Luigi Rizzo - Universita` di Pisa
 *
 * All rights reserved.
 *
 * Redistribution and use in source and binary forms, with or without
 * modification, are permitted provided that the following conditions
 * are met:
 * 1. Redistributions of source code must retain the above copyright
 *    notice, this list of conditions and the following disclaimer.
 * 2. Redistributions in binary form must reproduce the above copyright
 *    notice, this list of conditions and the following disclaimer in the
 *    documentation and/or other materials provided with the distribution.
 *
 * THIS SOFTWARE IS PROVIDED BY THE AUTHOR AND CONTRIBUTORS ``AS IS'' AND
 * ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE
 * IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE
 * ARE DISCLAIMED.  IN NO EVENT SHALL THE AUTHOR OR CONTRIBUTORS BE LIABLE
 * FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL
 * DAMAGES (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS
 * OR SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION)
 * HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT
 * LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY
 * OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF
 * SUCH DAMAGE.
 */
#ifndef _LINUX_CTYPE_H
#define _LINUX_CTYPE_H

/*
 * stub for the linux ctype.h - we remap it to the FreeBSD one.
 */
#include <sys/ctype.h>

/*
 * endiannes conversion
 */
static inline uint32_t le32_to_cpup(const __le32 *p)
{
	return p[0] + (p[1]<<8) + (p[2] << 16) + (p[3]<<24);
}

static inline uint16_t le16_to_cpup(const __le16 *p)
{
	return p[0] + p[1]*256;
}

static inline uint16_t le16_to_cpu(__le16 x)
{
	uint8_t *p = (uint8_t *)&x;
	return p[0] + p[1]*256;
}

#define cpu_to_le32(x)	__cpu_to_le32(x)
#define cpu_to_le16(x)	__cpu_to_le16(x)

static inline uint32_t __cpu_to_le32(uint32_t x)
{
	__le32 dst;
	uint8_t *p = (uint8_t *)&dst;
	p[0] = x & 0xff;
	p[1] = (x>>8) & 0xff;
	p[2] = (x>>16) & 0xff;
	p[3] = (x>>24) & 0xff;
	return dst;
}

static inline uint16_t __cpu_to_le16(uint16_t x)
{
	__le16 dst;
	uint8_t *p = (uint8_t *)&dst;
	p[0] = x & 0xff;
	p[1] = (x>>8) & 0xff;
	return dst;
}

unsigned int hweight8(unsigned int w);

#endif /* _LINUX_CTYPE_H */
