/*
 * Copyright (c) 2007 Luigi Rizzo - Universita` di Pisa
 *
 * All rights reserved.
 *              
 * Redistribution and use in source and binary forms, with or without
 * modification, are permitted provided that the following conditions
 * are met:
 * 1. Redistributions of source code must retain the above copyright
 *    notice, this list of conditions and the following disclaimer.
 * 2. Redistributions in binary form must reproduce the above copyright
 *    notice, this list of conditions and the following disclaimer in the
 *    documentation and/or other materials provided with the distribution.
 *
 * THIS SOFTWARE IS PROVIDED BY THE AUTHOR AND CONTRIBUTORS ``AS IS'' AND
 * ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE
 * IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE
 * ARE DISCLAIMED.  IN NO EVENT SHALL THE AUTHOR OR CONTRIBUTORS BE LIABLE
 * FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL
 * DAMAGES (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS
 * OR SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION)
 * HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT
 * LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY
 * OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF
 * SUCH DAMAGE.
 */

/*
 * $Id: init.h,v 1.20 2007/02/08 20:56:52 luigi Exp $
 *
 * Init info for linux-over-FreeBSD modules.
 * This has been basically rewritten from scratch and has significant
 * differences from the equivalent linux file because we need some 
 * emulation stuff as well. In particular, we define the following:
 *
 * - macro MODINFO_NAME(x) to generate a unique name for entry 'x',
 *   dependent on the DRIVER_NAME macro (set at compile time).
 *   We use this macro to name globally visible symbols, so to avoid
 *   name clashes in case we want to link the modules statically;
 *
 * - a linker set that is used to store information on the linux driver
 *   collected at compile time (through macros). These go into
 *   "struct bsd_module_init_t" entries in the ldev_info linker set;
 *
 * - "struct linux_dev_info" to store information on the linux driver
 *   collected at run time, either directly (e.g. through usb_register()),
 *   or later imported from the linker set.
 *   There is a global variable of this type, named MODINFO_NAME(info),
 *   because its fields are set by different source files.
 *
 * - functions to fill linux_dev_info
 */

#ifndef _LINUX_INIT_H
#define _LINUX_INIT_H

#include <sys/bus.h>		// device_t
#include <sys/linker_set.h>	// SET_DECLARE
/*
 * types and struct for the entries saved in the linker set.
 */
enum bsd_module_entry {
        BSD_MOD_UNDEFINED = 0,
        BSD_MOD_LOAD_HANDLER,
        BSD_MOD_UNLOAD_HANDLER,
        BSD_MOD_DEVICE_TABLE,
        BSD_MOD_DEVINFO,
};

struct bsd_module_init_t {
        enum bsd_module_entry   type;
        const char *            name;
        void *                  value;
};

SET_DECLARE(ldev_info, struct bsd_module_init_t);

/*
 * The structure where device-specific info is stored, either directly
 * (e.g. usb_register stores here) or after being collected from a
 * linker data_set.
 * There is one global variable of this type for each
 * driver, named MODINFO_NAME(info)
 */
struct linux_dev_info {
        int (*init_f)(void);
        int (*exit_f)(void);
        struct usb_device_id *device_table;
        struct usb_driver *usb_driver_desc;
        int initialized;
};

/*
 * Generate a unique variable name for the driver.
 * We need the two passes to cause the expansion of the
 * second argument.
 */
#define __M2(x, y) module_ ## y ## _ ## x
#define __M1(x, y) __M2(x, y)
#define MODINFO_NAME(x) __M1(x, DRIVER_NAME)

extern struct linux_dev_info MODINFO_NAME(info);

/*
 * Some info are collected in a linker set, below.
 */
#define _bsd_module_ty(t, ptr)				\
	static struct bsd_module_init_t _mod_##ptr = {	\
		.type = t,				\
		.name = #ptr,				\
		.value = ptr				\
	};						\
	DATA_SET(ldev_info, _mod_##ptr)

#define module_init(initfn)				\
	_bsd_module_ty(BSD_MOD_LOAD_HANDLER, initfn);

#define module_exit(exitfn)				\
	_bsd_module_ty(BSD_MOD_UNLOAD_HANDLER, exitfn);

/*
 * This is called at the beginning of the modevent_handler to copy the
 * information from the linker set to a struct where it is easier to use.
 */
void linux_devinfo_init(struct linux_dev_info *i);

/*
 * This is the basic usb device matching routine.
 */
const struct usb_device_id *
ldev_lookup(device_t dev, struct usb_device_id *p);

struct linux_usb_descriptors;	/* in linux/ldev_stub.h */
/*
 * Prepare the linux emulation descriptors before the linux calls
 */
int fill_linux_descriptors(device_t dev, struct linux_usb_descriptors *ld);

/* wrapper around tsleep */
int wait_event_body(void *wc, int flags);
#endif /* _LINUX_INIT_H */
