/*
 * Copyright (c) 2007 Luigi Rizzo - Universita` di Pisa
 *
 * All rights reserved.
 *
 * Redistribution and use in source and binary forms, with or without
 * modification, are permitted provided that the following conditions
 * are met:
 * 1. Redistributions of source code must retain the above copyright
 *    notice, this list of conditions and the following disclaimer.
 * 2. Redistributions in binary form must reproduce the above copyright
 *    notice, this list of conditions and the following disclaimer in the
 *    documentation and/or other materials provided with the distribution.
 *
 * THIS SOFTWARE IS PROVIDED BY THE AUTHOR AND CONTRIBUTORS ``AS IS'' AND
 * ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE
 * IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE
 * ARE DISCLAIMED.  IN NO EVENT SHALL THE AUTHOR OR CONTRIBUTORS BE LIABLE
 * FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL
 * DAMAGES (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS
 * OR SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION)
 * HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT
 * LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY
 * OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF
 * SUCH DAMAGE.
 */

#ifndef _LINUX_FS_H
#define _LINUX_FS_H

#include <linux/err.h>
#include <linux/namei.h>
#include <linux/stat.h>
#include <asm/atomic.h>

#include <sys/file.h>
#include <sys/filedesc.h>

/*
 * $Id: fs.h,v 1.4 2007/01/27 16:52:28 luigi Exp $
 * Prototype of the struct file_operations used in device drivers.
 * We also include here a placeholder for 'struct file'
 */

#define FMODE_READ	1
#define FMODE_WRITE	2

struct address_space;

/* from file.h */
struct linux_file {
	struct path		f_path;
	const struct file_operations *f_op;
	atomic_t		f_count;
	int			f_flags;
	mode_t			f_mode;
	loff_t			f_pos;
	struct address_space	*f_mapping;
	unsigned long		f_version;
	void			*private_data;
};

/*
 * XXX that's quite dirty, from now on all `file' identifiers will be
 * replaced with linux_file.  this may cause *a lot* of nasty things
 * and hard to find errors, but should work for KVM.
 */
#define	file	linux_file

// struct kiocb;	/* in aio.h */
struct poll_table_struct;	// XXX dummy
// struct dentry;	// XXX dummy
struct vm_area_struct;	// XXX dummy
// struct file_lock;	// XXX dummy
// typedef void * filldir_t;	// XXX dummy
// typedef void * read_actor_t;	// XXX dummy

#define no_llseek	NULL

struct inode;

/*
 * NOTE:
 * read, write, poll, fsync, readv, writev, unlocked_ioctl and compat_ioctl
 * can be called without the big kernel lock held in all filesystems.
 */
struct file_operations {
        struct module *owner;
        loff_t (*llseek) (struct file *, loff_t, int);
        ssize_t (*read) (struct file *, char __user *, size_t, loff_t *);
        // ssize_t (*aio_read) (struct kiocb *, char __user *, size_t, loff_t);
        ssize_t (*write) (struct file *, const char __user *, size_t, loff_t *);
        // ssize_t (*aio_write) (struct kiocb *, const char __user *, size_t, loff_t);
        // int (*readdir) (struct file *, void *, filldir_t);
        unsigned int (*poll) (struct file *, struct poll_table_struct *);
        int (*ioctl) (struct inode *, struct file *, unsigned int, unsigned long);
        long (*unlocked_ioctl) (struct file *, unsigned int, unsigned long);
        long (*compat_ioctl) (struct file *, unsigned int, unsigned long);
        int (*mmap) (struct file *, struct vm_area_struct *);
        int (*open) (struct inode *, struct file *);
        int (*flush) (struct file *);
        int (*release) (struct inode *, struct file *);
        // int (*fsync) (struct file *, struct dentry *, int datasync);
        // int (*aio_fsync) (struct kiocb *, int datasync);
        // int (*fasync) (int, struct file *, int);
        // int (*lock) (struct file *, int, struct file_lock *);
        // ssize_t (*readv) (struct file *, const struct iovec *, unsigned long, loff_t *);
        // ssize_t (*writev) (struct file *, const struct iovec *, unsigned long, loff_t *);
        // ssize_t (*sendfile) (struct file *, loff_t *, size_t, read_actor_t, void *);
        // ssize_t (*sendpage) (struct file *, struct page *, int, size_t, loff_t *, int);
        // unsigned long (*get_unmapped_area)(struct file *, unsigned long, unsigned long, unsigned long, unsigned long);
        int (*check_flags)(int);
        int (*dir_notify)(struct file *filp, unsigned long arg);
        // int (*flock) (struct file *, int, struct file_lock *);
        // ssize_t (*splice_write)(struct pipe_inode_info *, struct file *, loff_t *, size_t, unsigned int);
        // ssize_t (*splice_read)(struct file *, loff_t *, struct pipe_inode_info *, size_t, unsigned int);
};

#define	I_DIRTY_SYNC		1
#define	I_DIRTY_DATASYNC	2
#define	I_DIRTY_PAGES		4

#define	I_DIRTY	(I_DIRTY_SYNC | I_DIRTY_DATASYNC | I_DIRTY_PAGES)

struct inode {
	uid_t			i_uid;
	gid_t			i_gid;
	struct timespec		i_atime;
	struct timespec		i_mtime;
	struct timespec		i_ctime;
	struct file_operations	*i_fop;
	umode_t			i_mode;
	unsigned long		i_state;
	struct address_space	*i_mapping;
};

static inline void iput(struct inode *ino)
{
}

#define	get_empty_filp() kzalloc(sizeof(struct file), GFP_KERNEL)

struct super_block;
struct super_operations;

struct file_system_type {
	const char *name;
	int (*get_sb)(struct file_system_type *, int,
			const char *, void *, struct vfsmount *);
	void (*kill_sb)(struct super_block *);
};

static inline int register_filesystem(struct file_system_type *fs_type)
{
	return 0;
}

static inline int unregister_filesystem(struct file_system_type *fs_type)
{
	return 0;
}

static inline void kill_anon_super(struct super_block *sb)
{
}

static inline int get_sb_pseudo(struct file_system_type *fs_type,
		char *name, const struct super_operations *ops,
		unsigned long magic, struct vfsmount *mnt)
{
	return 0;
}

#define	new_inode(sb) kzalloc(sizeof(struct inode), GFP_KERNEL)

static inline struct vfsmount *kern_mount(struct file_system_type *fs_type)
{
	return 0;
}

#endif	/* _LINUX_FS_H */
