#ifndef _LINUX_CPUMASK_H
#define _LINUX_CPUMASK_H

#include <machine/param.h>
#include <sys/smp.h>

#define	for_each_online_cpu(cpu)			\
	for ((cpu) = 0; (cpu) < MAXCPU; (cpu)++)	\
		if (!CPU_ABSENT(cpu))

#endif
