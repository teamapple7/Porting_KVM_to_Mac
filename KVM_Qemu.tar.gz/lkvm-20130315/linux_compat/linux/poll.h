#ifndef _LINUX_POLL_H
#define _LINUX_POLL_H

#include <sys/poll.h>	/* POLLIN and friends */
// #include <linux/compiler.h>
#include <linux/wait.h>
// #include <linux/string.h>
// #include <linux/mm.h>
// #include <asm/uaccess.h>


struct poll_table_struct;

/*
 * structures and helpers for f_op->poll implementations
 */
typedef void (*poll_queue_proc)(struct file *,
	wait_queue_head_t *, struct poll_table_struct *);


struct poll_table_struct {
        poll_queue_proc qproc;
};

typedef struct poll_table_struct poll_table;

static inline void
poll_wait(struct file * filp, wait_queue_head_t * wait_address,
	poll_table *p)
{
        if (p && wait_address)
                p->qproc(filp, wait_address, p);
}

#endif /* _LINUX_POLL_H */
