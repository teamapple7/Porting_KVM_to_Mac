#ifndef _LINUX_DEBUGFS_H
#define _LINUX_DEBUGFS_H

#include <linux/fs.h>

static inline
struct dentry *debugfs_create_dir(const char *name,
					struct dentry *parent)
{
	return 0;
}

static inline
struct dentry *debugfs_create_u32(const char *name, mode_t mode,
					struct dentry *parent, u32 *value)
{
	return 0;
}

static inline
void debugfs_remove(struct dentry *dentry)
{
}

#endif
