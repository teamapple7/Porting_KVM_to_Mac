#ifndef _LINUX_MM_H
#define _LINUX_MM_H

#include <asm/pgtable.h>
#include <asm/processor.h>
#include <linux/page.h>
#include <linux/sched.h>
#include <linux/fs.h>

struct vm_operations_struct;
/*
 * This struct defines a memory VMM memory area. There is one of these
 * per VM-area/task.  A VM area is any part of the process virtual memory
 * space that has a special rule for the page-fault handlers (ie a shared
 * library, the executable area etc).
 * XXX we do the minimum we need.
 */
struct vm_area_struct {
	unsigned long vm_start;         /* Our start address within vm_mm. */
	unsigned long vm_end;           /* The first byte after our end address
						within vm_mm. */
	unsigned long vm_flags;         /* Flags, listed below. */

        unsigned long vm_pgoff;         /* Offset (within vm_file) in PAGE_SIZE
                                           units, *not* PAGE_CACHE_SIZE */

        struct vm_operations_struct * vm_ops;
	struct file *vm_file;

        void * vm_private_data;         /* was vm_pte (shared mem) */

};

/*
 * vm_flags..
 */
#define VM_READ         0x00000001      /* currently active flags */
#define VM_WRITE        0x00000002
#define VM_EXEC         0x00000004
#define VM_SHARED       0x00000008

/* mprotect() hardcodes VM_MAYREAD >> 4 == VM_READ, and so for r/w/x bits. */
#define VM_MAYREAD      0x00000010      /* limits for mprotect() etc */
#define VM_MAYWRITE     0x00000020
#define VM_MAYEXEC      0x00000040
#define VM_MAYSHARE     0x00000080

#define VM_GROWSDOWN    0x00000100      /* general info on the segment */
#define VM_GROWSUP      0x00000200
#define VM_PFNMAP       0x00000400      /* Page-ranges managed without "struct page", just pure
 PFN */
#define VM_DENYWRITE    0x00000800      /* ETXTBSY on write attempts.. */

#define VM_EXECUTABLE   0x00001000
#define VM_LOCKED       0x00002000
#define VM_IO           0x00004000      /* Memory mapped I/O or similar */

                                        /* Used by sys_madvise() */
#define VM_SEQ_READ     0x00008000      /* App will access data sequentially */
#define VM_RAND_READ    0x00010000      /* App will not benefit from clustered reads */

#define VM_DONTCOPY     0x00020000      /* Do not copy this vma on fork */
#define VM_DONTEXPAND   0x00040000      /* Cannot expand with mremap() */
#define VM_RESERVED     0x00080000      /* Count as reserved_vm like IO */
#define VM_ACCOUNT      0x00100000      /* Is a VM accounted object */
#define VM_HUGETLB      0x00400000      /* Huge TLB Page VM */
#define VM_NONLINEAR    0x00800000      /* Is non-linear (remap_file_pages) */
#define VM_MAPPED_COPY  0x01000000      /* T if mapped copy of data (nommu mmap) */
#define VM_INSERTPAGE   0x02000000      /* The vma has had "vm_insert_page()" done on it */

#ifndef VM_STACK_DEFAULT_FLAGS          /* arch can override this */
#define VM_STACK_DEFAULT_FLAGS VM_DATA_DEFAULT_FLAGS
#endif

#define	NOPAGE_SIGBUS	0
#define	VM_FAULT_MINOR	0

/*
 * These are the virtual MM functions - opening of an area, closing and   
 * unmapping it (needed to keep files on disk up-to-date etc), pointer
 * to the functions called when a no-page or a wp-page exception occurs.
 */
struct vm_operations_struct {
        void (*open)(struct vm_area_struct * area);
        void (*close)(struct vm_area_struct * area);
	struct page *(*nopage)(struct vm_area_struct *area, unsigned
				long address, int *type);
	/* there are more */
};

int vm_insert_page(struct vm_area_struct *, unsigned long addr, struct page *);

unsigned long vmalloc_to_pfn(void *addr);

int remap_pfn_range(struct vm_area_struct *, unsigned long addr,
                        unsigned long pfn, unsigned long size, pgprot_t);

static inline void *page_address(struct page *page)
{
#ifdef DEBUG_ADDR
	KASSERT(pfn_to_page(page_to_pfn(page)) == page, ("page_address"));
#endif
	return page->__va;
}

static inline void get_page(struct page *page)
{
}

static inline unsigned long page_private(struct page *page)
{
#ifdef DEBUG_ADDR
	KASSERT(pfn_to_page(page_to_pfn(page)) == page, ("page_private"));
#endif
	return page->private;
}

static inline void set_page_private(struct page *page, unsigned long v)
{
#ifdef DEBUG_ADDR
	KASSERT(pfn_to_page(page_to_pfn(page)) == page, ("set_page_private"));
#endif
	page->private = v;
}

/* XXX this should not be done so late! */
#include <linux/page.h>
#include <linux/gfp.h>

/* from slab.h */
#include <dev/usb/usb.h>
#define kzalloc(sz, gfp_t)	malloc(sz, M_USBDEV, M_NOWAIT | M_ZERO)

#endif /* _LINUX_MM_H */
