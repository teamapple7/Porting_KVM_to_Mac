#ifndef _LINUX_MOUNT_H
#define _LINUX_MOUNT_H

#include <asm/atomic.h>

struct super_block;

struct vfsmount {
	struct super_block	*mnt_sb;
	atomic_t		mnt_count;
};

static inline struct vfsmount *mntget(struct vfsmount *mnt)
{
	return 0;
}

static inline void mntput(struct vfsmount *mnt)
{
}

#endif
