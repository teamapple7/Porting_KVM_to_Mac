#ifndef _LINUX_LINKAGE_H
#define _LINUX_LINKAGE_H

#define	asmlinkage

#endif
