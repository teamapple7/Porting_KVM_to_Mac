#ifndef _LINUX_KOBJECT_H
#define _LINUX_KOBJECT_H

struct kobject {
};

struct kset {
};

#define	set_kset_name(str)	.kset = { }

#endif
