#ifndef _LINUX_MODULEPARAM_H
#define _LINUX_MODULEPARAM_H

/*
 * module_param are user-settable controls that influence the
 * behaviour of a module.
 * The best way to implement them is, perhaps, a sysctl.
 */
#if 0
/* leave it empty for now... */
#define module_param(name, type, perm)		\
	type param__##name
#else
#include <sys/sysctl.h>

#define __a2(y) _debug_ ## y
#define __a1(y) __a2(y)
#define	_mod_sysctl_name __a1(DRIVER_NAME)

/* expansion of sysctl arguments */
#define SYSCTL_DECLn(x) SYSCTL_DECL1(x)
#define SYSCTL_DECL1(x) SYSCTL_DECL(x)
	

#define SYSCTL_NODEn(a, b, c, d, e, f) SYSCTL_NODE1(a, b, c, d, e, f)
#define SYSCTL_NODE1(a, b, c, d, e, f) SYSCTL_NODE(a, b, c, d, e, f)

#define	SYSCTL_INTn(a, b, c, d, e, f, g) SYSCTL_INT1(a, b, c, d, e, f, g);  
#define	SYSCTL_INT1(a, b, c, d, e, f, g) SYSCTL_INT(a, b, c, d, e, f, g);  

SYSCTL_DECLn(_mod_sysctl_name);

#define module_param(name, type, perm)		\
	SYSCTL_INTn(_mod_sysctl_name, OID_AUTO, name, CTLFLAG_RW,	\
    &name, 0, "ldev " #name);  
#endif

#define module_param_named(_name, _var, _ty, _val)

#define module_param_array(name, type, ptr, perm)	\
	struct __dummy__##name {			\
		int *p;					\
	} __dummy_##name##__obj = { ptr }

#endif /* _LINUX_MODULEPARAM_H */
