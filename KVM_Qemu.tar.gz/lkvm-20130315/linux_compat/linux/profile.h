#ifndef _LINUX_PROFILE_H
#define _LINUX_PROFILE_H

#define	KVM_PROFILING	4

extern int prof_on;

static inline void profile_hit(int i, void *ip)
{
}

#endif
