#ifndef _LINUX_INTERRUPT_H
#define _LINUX_INTERRUPT_H

#include <machine/cpufunc.h>

#define	local_irq_enable()	enable_intr()
#define	local_irq_disable()	disable_intr()

#endif
