#ifndef __LINUX_MUTEX_H
#define __LINUX_MUTEX_H

#include <sys/lock.h>
#include <sys/mutex.h>
#include <asm/semaphore.h>

struct mutex {
	struct semaphore sem;
};

#define mutex_init(_m)		init_MUTEX(&(_m)->sem);
#define mutex_lock(_m)		down(&(_m)->sem);

static inline int
mutex_lock_interruptible(struct mutex *_m)
{
	down(&_m->sem);
	return 0;
}

#define mutex_unlock(_m)	up(&(_m)->sem)

static inline int mutex_trylock(struct mutex *_m)
{
	return sema_trywait(&_m->sem.sema);
}

#endif /* __LINUX_MUTEX_H */
