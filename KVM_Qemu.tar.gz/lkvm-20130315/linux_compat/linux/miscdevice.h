#ifndef _LINUX_MISCDEVICE_H
#define _LINUX_MISCDEVICE_H

#include <sys/conf.h>
#include <sys/param.h>
#include <linux/fs.h>
#include <linux/module.h>

#define	MISC_DYNAMIC_MINOR	255

/*
 * misc device descriptor
 */
struct miscdevice {
	int minor;
	const char *name;
	const struct file_operations *fops;
	struct list_head list;
	struct device *parent;
	struct device *this_device;

	/*
	 * static configuration: each miscdevice is associated to a
	 * character device.
	 */
	struct cdevsw cdevsw;
	struct cdev *cdev;

	/*
	 * dynamic configuration: a miscdevice can have at most
	 * one user, vopen is used to count the references to it,
	 * ino and file are passed to the Linux fops.
	 */
	int vopen;
	struct inode ino;
	struct file file;
};

int misc_register(struct miscdevice *misc);
int misc_deregister(struct miscdevice *misc);

#endif
