#ifndef __LINUX_GFP_H
#define __LINUX_GFP_H

#define	__GFP_HIGHMEM	((__force gfp_t)0x02u)
#define	__GFP_DMA32	((__force gfp_t)0x04u)

struct page *alloc_pages(gfp_t gfp_mask, unsigned long order);
void __free_pages(struct page *page, unsigned long order);

static inline struct page *
alloc_page(gfp_t gfp_mask)
{
	return alloc_pages(gfp_mask, 0);
}

static inline struct page *
alloc_pages_node(int nid, gfp_t gfp_mask, unsigned long order)
{
	return alloc_pages(gfp_mask, order);
}

static inline unsigned long
__get_free_page(gfp_t gfp_mask)
{
	struct page *page;

	page = alloc_pages(gfp_mask, 0);
	if (page == NULL)
		return 0;

	return (unsigned long)page_address(page);
}

static inline void
free_page(unsigned long addr)
{
	__free_pages(pfn_to_page(__pa((void *)addr) >> PAGE_SHIFT), 0);
}

static inline void
free_pages(unsigned long addr, unsigned long order)
{
	__free_pages(pfn_to_page(__pa((void *)addr) >> PAGE_SHIFT), order);
}

static inline void
__free_page(struct page *page)
{
	__free_pages(page, 0);
}

#endif /* __LINUX_GFP_H */
