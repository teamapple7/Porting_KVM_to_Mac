#ifndef _LINUX_PAGE_H
#define _LINUX_PAGE_H

#include <sys/param.h>
#include <sys/queue.h>
#include <vm/vm.h>
#include <vm/vm_param.h>
#include <vm/vm_page.h>
#include <vm/pmap.h>

/* in page.h */
typedef struct { unsigned long pgprot; } pgprot_t;
#define __pgprot(x)     ((pgprot_t) { (x) } )

#define	PAGE_KERNEL	__pgprot(0)

#define PAGE_SHIFT	12

#define	PAGE_MASK_compat	(~(PAGE_SIZE - 1))

/* in page-flags.h */
#define SetPageReserved(page)   do {} while (0) // set_bit(PG_reserved, &(page)->flags)
#define ClearPageReserved(page) do {} while (0) // clear_bit(PG_reserved, &(page)->flags)

/* end page-flags.h */

/* in pgtable.h */

/* XXX remap to freebsd */
#define _PAGE_PRESENT   0x001
#define _PAGE_RW        0x002
#define _PAGE_USER      0x004
#define _PAGE_ACCESSED  0x020

#define PAGE_SHARED \
        __pgprot(_PAGE_PRESENT | _PAGE_RW | _PAGE_USER | _PAGE_ACCESSED)

/*
 * Physical frame descriptor.  We hold an array of the vm_page_t objects
 * corresponding to this page.  __va is the address the page is mapped
 * to in the kernel address space.
 */
#include <ldev_vm.h>

struct page {
	void		*__va;
	long		order;
	struct memreg	*memreg;

	unsigned long	private;
	LIST_ENTRY(page) hlist;

	struct memop	memop;
};

struct page *vmalloc_to_page(void *addr);

/* Align the pointer to the (next) page boundary.
 * Note that on FreeBSD, PAGE_MASK = PAGE_SIZE -1,
 * whereas on Linux PAGE_MASK = (~(PAGE_SIZE-1))
 */
 
#define PAGE_ALIGN(addr)        (((addr)+PAGE_SIZE-1)&(~(PAGE_SIZE - 1)))

/*
 * I think PAGE_OFFSET is the start of the kernel (virtual?) addres space.
 * Let's set it at 0xC0000000 for the time being. Not sure it is correct.
 * XXX note, this stuff is used in the mmap support.
 */
#define PAGE_OFFSET	0xC0000000	// XXX check it...

static inline unsigned long __pa(void *x)
{
	return vtophys((vm_offset_t)x);
}

struct page *pfn_to_page(u_long pfn);

static inline void *__va(unsigned long x)
{
	struct page *page;

	page = pfn_to_page(x >> PAGE_SHIFT);
	return page->__va;
}

static inline struct page *virt_to_page(void *kaddr)
{
	return pfn_to_page(__pa(kaddr) >> PAGE_SHIFT);
}

static inline unsigned long page_to_pfn(struct page *page)
{
	return __pa(page->__va) >> PAGE_SHIFT;
}

#define	offset_in_page(p)	((unsigned long)(p) & PAGE_MASK)

static inline int get_order(unsigned long size)
{
	int order;

	size = (size - 1) >> (PAGE_SHIFT - 1);
	order = -1;
	do {
		size >>= 1;
		order++;
	} while (size);

	return order;
}

#endif /* _LINUX_PAGE_H */
