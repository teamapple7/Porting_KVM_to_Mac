#ifndef _LINUX_DEVICE_H_
#define _LINUX_DEVICE_H_

#include <linux/pm.h>

// #include <linux/list.h>
/* in sysfs.h */
struct attribute {
        const char              * name;
        struct module           * owner;
        mode_t                  mode;
};

/* end sysfs.h */

struct class;
struct class_device;

struct class_attribute {
        struct attribute        attr;
        ssize_t (*show)(struct class *, char * buf);
        ssize_t (*store)(struct class *, const char * buf, size_t count);
};

struct class_device_attribute {
        struct attribute        attr;
        ssize_t (*show)(struct class_device *, char * buf);
        ssize_t (*store)(struct class_device *, const char * buf, size_t count);
};

#define __ATTR(_name,_mode,_show,_store) {	\
        .attr = {				\
		.name = __stringify(_name),	\
		.mode = _mode,			\
		.owner = THIS_MODULE },		\
        .show   = _show,			\
        .store  = _store,			\
}

#define CLASS_DEVICE_ATTR(_name,_mode,_show,_store)             \
	struct class_device_attribute \
		__attribute__ ((unused)) \
		class_device_attr_##_name =       \
		__ATTR(_name,_mode,_show,_store)

/**
 * struct class_device - class devices
 * @class: pointer to the parent class for this class device.  This is required.
 * @devt: for internal use by the driver core only.
 * @node: for internal use by the driver core only.
 * @kobj: for internal use by the driver core only.
 * @devt_attr: for internal use by the driver core only.
 * @groups: optional additional groups to be created
 * @dev: if set, a symlink to the struct device is created in the sysfs
 * directory for this struct class device.
 * @class_data: pointer to whatever you want to store here for this struct
 * class_device.  Use class_get_devdata() and class_set_devdata() to get and
 * set this pointer.
 * @parent: pointer to a struct class_device that is the parent of this struct
 * class_device.  If NULL, this class_device will show up at the root of the
 * struct class in sysfs (which is probably what you want to have happen.)
 * @release: pointer to a release function for this struct class_device.  If
 * set, this will be called instead of the class specific release function.
 * Only use this if you want to override the default release function, like
 * when you are nesting class_device structures.
 * @uevent: pointer to a uevent function for this struct class_device.  If
 * set, this will be called instead of the class specific uevent function.
 * Only use this if you want to override the default uevent function, like
 * when you are nesting class_device structures.
 */
struct class_device {
#if 0
	struct list_head        node;


        struct kobject          kobj;
        struct class            * class;        /* required */
        dev_t                   devt;           /* dev_t, creates the sysfs "dev" */
        struct class_device_attribute *devt_attr;
        struct class_device_attribute uevent_attr;
        struct device           * dev;          /* not necessary, but nice to have */
        void                    * class_data;   /* class-specific data */
        struct class_device     *parent;        /* parent of this child device, if there is one */
        struct attribute_group  ** groups;      /* optional groups */

        void    (*release)(struct class_device *dev);
        int     (*uevent)(struct class_device *dev, char **envp,
                           int num_envp, char *buffer, int buffer_size);
        char    class_id[BUS_ID_SIZE];  /* unique to this class */
#endif
};

/*
 * In FreeBSD, a struct device is defined only in kern/subr_bus.c
 */
struct device {
#if 0
        struct klist            klist_children;
        struct klist_node       knode_parent;           /* node in sibling list */
        struct klist_node       knode_driver;
        struct klist_node       knode_bus;
#endif
        struct device   * parent;
#if 0

        struct kobject kobj;
        char    bus_id[BUS_ID_SIZE];    /* position on parent bus */
        struct device_attribute uevent_attr;

        struct semaphore        sem;    /* semaphore to synchronize calls to
                                         * its driver.
                                         */

        struct bus_type * bus;          /* type of bus device is on */
        struct device_driver *driver;   /* which driver has allocated this
                                           device */
#endif
        void            *driver_data;   /* data private to the driver */
#if 0
        void            *platform_data; /* Platform specific data, device
                                           core doesn't touch it */
        void            *firmware_data; /* Firmware specific data (e.g. ACPI,
                                           BIOS data),reserved for device core*/
        struct dev_pm_info      power;

        u64             *dma_mask;      /* dma mask (if dma'able device) */
        u64             coherent_dma_mask;/* Like dma_mask, but for
                                             alloc_coherent mappings as
                                             not all hardware supports
                                             64 bit addresses for consistent
                                             allocations such descriptors. */

        struct list_head        dma_pools;      /* dma pools (if dma'ble) */

        struct dma_coherent_mem *dma_mem; /* internal for coherent mem
                                             override */

        void    (*release)(struct device * dev);
#endif
};

static inline void *
dev_get_drvdata (struct device *dev)
{
        return dev->driver_data;
}

static inline void
dev_set_drvdata (struct device *dev, void *data)
{
        dev->driver_data = data;
}

#endif /* _LINUX_DEVICE_H_ */
