#ifndef _LINUX_MAGIC_H
#define _LINUX_MAGIC_H

#define	KVMFS_SUPER_MAGIC	0x19700426

#endif
