#ifndef _LINUX_CPU_H
#define _LINUX_CPU_H

struct notifier_block;

static inline int register_cpu_notifier(struct notifier_block *nb)
{
	return 0;
}

static inline void unregister_cpu_notifier(struct notifier_block *nb)
{
}

#endif
