#ifndef __LINUX_KERNEL_H
#define __LINUX_KERNEL_H

#include <asm/bitops.h>
#include <linux/bug.h>
#include <linux/linkage.h>

#define DBG(fmt , A...)			\
	printf("%d [%4d] %s: " fmt , ticks, __LINE__, __FUNCTION__, ## A)

#define BUG()	DBG("BUG\n")

/*
 * unfortunately printf is in systm.h
 */
// int     printf(const char *, ...) __printflike(1, 2);

/*
 * These macros are used to navigate within nested structures.
 * 
 * offsetof(TYPE, MEMBER) returns the offset of the member in the type.
 * It is already in the base FreeBSD so we don't redefine it
 * 
 * container_of - cast a member of a structure out to the containing structure
 * @ptr:        the pointer to the member.
 * @type:       the type of the container struct this is embedded in.
 * @member:     the name of the member within the struct.
 * 
 * Note that this implementation is slightly different from the linux one,
 * which triggered sme compiler warnings.
 */
#define container_of(ptr, type, member) ({			\
	__typeof( ((type *)0)->member ) *__mptr = (ptr);	\
	(type *)( (char *)__mptr - offsetof(type,member) );})
  
#define ARRAY_SIZE(x) (sizeof(x) / sizeof((x)[0]))

#define	KERN_EMERG	"<0>"	/* system is unusable			*/
#define	KERN_ALERT	"<1>"	/* action must be taken immediately	*/
#define	KERN_CRIT	"<2>"	/* critical conditions			*/
#define	KERN_ERR	"<3>"	/* error conditions			*/
#define	KERN_WARNING	"<4>"	/* warning conditions			*/
#define	KERN_NOTICE	"<5>"	/* normal but significant condition	*/
#define	KERN_INFO	"<6>"	/* informational			*/
#define	KERN_DEBUG	"<7>"	/* debug-level messages			*/

#define	__ALIGN_MASK(x,mask)	(((x)+(mask))&~(mask))
#define ALIGN_compat(x,a)	__ALIGN_MASK(x,(typeof(x))(a)-1)

static inline void dump_stack(void)
{
}

#endif	/* __LINUX_KERNEL_H */
