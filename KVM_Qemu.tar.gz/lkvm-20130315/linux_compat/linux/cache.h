#ifndef _LINUX_CACHE_H
#define _LINUX_CACHE_H

#include <linux/kernel.h>

#endif
