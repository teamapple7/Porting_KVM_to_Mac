#ifndef _LINUX_DCACHE_H
#define _LINUX_DCACHE_H

#include <linux/cache.h>

struct inode;

struct dentry {
	struct inode *d_inode;
};

#define	d_alloc_anon(inode) kzalloc(sizeof(struct dentry), GFP_KERNEL)

#endif
