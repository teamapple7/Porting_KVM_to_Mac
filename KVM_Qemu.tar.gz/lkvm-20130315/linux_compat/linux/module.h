/*
 * Copyright (c) 2007 Luigi Rizzo - Universita` di Pisa
 *
 * All rights reserved.
 *
 * Redistribution and use in source and binary forms, with or without
 * modification, are permitted provided that the following conditions
 * are met:
 * 1. Redistributions of source code must retain the above copyright
 *    notice, this list of conditions and the following disclaimer.
 * 2. Redistributions in binary form must reproduce the above copyright
 *    notice, this list of conditions and the following disclaimer in the
 *    documentation and/or other materials provided with the distribution.
 *
 * THIS SOFTWARE IS PROVIDED BY THE AUTHOR AND CONTRIBUTORS ``AS IS'' AND
 * ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE
 * IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE
 * ARE DISCLAIMED.  IN NO EVENT SHALL THE AUTHOR OR CONTRIBUTORS BE LIABLE
 * FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL
 * DAMAGES (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS
 * OR SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION)
 * HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT
 * LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY
 * OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF
 * SUCH DAMAGE.
 */

#ifndef _LINUX_MODULE_H
#define _LINUX_MODULE_H

/*
 * $Id: module.h,v 1.25 2007/02/08 21:31:43 luigi Exp $
 *
 * Emulation of linux/module.h
 *
 * We start including all the FreeBSD kernel files normally used by modules,
 * followed by the linux-specific files (those in this directory).
 */

#include <sys/param.h>
/* conflict on list macros, try -D_SYS_QUEUE_H_ */
#if 0 // ndef _SYS_QUEUE_H_
#define _SYS_QUEUE_H_	/* disable lists */
#endif
#include <sys/systm.h>	// conflict on version

#include <sys/kernel.h>		/* ticks */
#include <sys/ioccom.h>		/* _IOR and friends */
// #include <sys/module.h>
// #include <sys/bus.h>
//- #include <sys/conf.h>	// list.h
#include <sys/fcntl.h>	/* O_NONBLOCK */
// #include <sys/tty.h>
// #include <sys/selinfo.h>
// #include <sys/poll.h>
// #include <sys/uio.h>
// #include <sys/sysctl.h>
// #include <sys/malloc.h>
// #include <sys/mman.h>
// #include <vm/vm.h>
// #include <vm/pmap.h>

#include <asm/atomic.h>

/*
 * now the linux-specific stuff
 */
#include <linux/compiler.h>
#include <linux/types.h>
//#include <linux/kernel.h>
//#include <linux/init.h>
#include <linux/ctype.h>	// XXX our types...
#include <linux/device.h>
#include <linux/wait.h>
#include <linux/videodev.h>	// __u16 etc
#include <linux/moduleparam.h>	// module_param etc
//#include <linux/fs.h>	// file etc.

#define	EXPORT_SYMBOL_GPL(sym)

/* in stat.h */
/* this is used in CLASS_DEVICE_ATTR() macros.
 * We don't really care about it by now.
 */
#define	S_IRUGO		0	// XXX not really

/* in errno.h */
/* Should never be seen by user programs */
#define ERESTARTSYS     512
#define	ENOIOCTLCMD     515     /* No ioctl command */

#define	ENODATA		61	/* No data available (2.4 only ?) */
#define ETIME           62      /* Timer expired */
#define ENOSR           63      /* Out of streams resources */
#define	EREMOTEIO	121	/* Remote I/O error */

/* v4l2 defs */
#define VFL_TYPE_GRABBER        0
#define VFL_TYPE_VBI            1
#define VFL_TYPE_RADIO          2
#define VFL_TYPE_VTX            3

/* videodev.h extensions */
struct video_device {
        /* device info */
        struct device *dev;
        char name[32];
        int type;       /* v4l1 */
        int type2;      /* v4l2 */
        int hardware;
        int minor;

        /* device ops + callbacks */
        const struct file_operations *fops;
        void (*release)(struct video_device *vfd);


#if 1 /* to be removed in 2.6.15 */
        /* obsolete -- fops->owner is used instead */
        struct module *owner;
        /* dev->driver_data will be used instead some day.
         * Use the video_{get|set}_drvdata() helper functions,
         * so the switch over will be transparent for you.
         * Or use {pci|usb}_{get|set}_drvdata() directly. */
        void *priv;	/* we use this as a pointer to the softc */
#endif

        /* for videodev.c intenal usage -- please don't touch */
        int users;                     /* video_exclusive_{open|close} ... */
        struct mtx lock;             /* ... helper function uses these   */	// XXX was mutex
        char devfs_name[64];           /* devfs */
	struct class_device class_dev; /* sysfs */
};

/*
 * These two are obsolete and might be removed
 */
static inline void *video_get_drvdata(struct video_device *dev)
{
        return dev->priv;
}
  
static inline void video_set_drvdata(struct video_device *dev, void *data)
{
        dev->priv = data; 
}  

#include <linux/fs.h>
struct inode;

struct video_device* video_devdata(struct file*);	
int video_usercopy(struct inode *inode, struct file *file,
      unsigned int cmd, unsigned long arg,
      int (*func)(struct inode *inode, struct file *file,
		  unsigned int cmd, void *arg));

int video_register_device(struct video_device *, int type, int nr);
void video_unregister_device(struct video_device *);

#define to_video_device(cd) container_of(cd, struct video_device, class_dev)


struct video_device *video_device_alloc(void);
void video_device_release(struct video_device *vfd);

/* do something useless to silence compiler.
 * XXX try unused or something better
 */
#define video_device_create_file(a, b)	({void *x=a; (x == a) ? 0 : 1;})

#if 0
int
video_device_create_file(struct video_device *vfd,
                         struct class_device_attribute *attr);
#endif

/* in linux/module.h */
/*
 * In our emulation layer, the device table is stored in a linker set.
 */
#define MODULE_DEVICE_TABLE(type,name)			\
	_bsd_module_ty(BSD_MOD_DEVICE_TABLE, name)

#define MODULE_PARM_DESC(_parm, desc)
#define MODULE_AUTHOR(_name)
#define MODULE_DESCRIPTION(_name)
#define MODULE_LICENSE(_name)

// extern struct module __this_module;
#define THIS_MODULE (NULL)	// (&__this_module)

/* in uaccess.h */
unsigned long copy_to_user(void __user *to,
                                const void *from, unsigned long n);
unsigned long copy_from_user(void *to,
                                const void __user *from, unsigned long n);

#define info(format, arg...) \
	printf("%s: " format "\n", __FUNCTION__ , ## arg)

/* maybe somewhere else ? */
#define printk(fmt , args...) printf(fmt , ##args)
#define warn(X...)                      printf(X)
#define dbg(X...)                       printf(X)
#define err(X...)                       printf(X)
 
// #define udelay(x)       tsleep("spca", PCATCH, "xx", x*HZ/1000000)

void *kmalloc(size_t size, gfp_t gfp_mask);
void kfree(void *ptr);

#define	HZ	hz	// on freebsd...
#define udelay(t)	DELAY(t)
void linux_msleep(int ms);

#define msleep_compat(ms)	linux_msleep(ms)
#undef msleep
#define msleep(ms)	linux_msleep(ms)
// #define mdelay(ms)	linux_msleep(ms)	// maybe DELAY... */
#define mdelay(ms)	DELAY(ms)	// maybe DELAY... */

/* in gfp.h */

#define __GFP_WAIT      ((gfp_t)0x10u)  /* Can wait and reschedule? */
#define __GFP_HIGH      ((gfp_t)0x20u)  /* Should access emergency pools? */
#define __GFP_IO        ((gfp_t)0x40u)  /* Can start physical IO? */
#define __GFP_FS        ((gfp_t)0x80u)  /* Can call down to low-level FS? */
#define __GFP_COLD      ((gfp_t)0x100u) /* Cache-cold page required */
#define __GFP_NOWARN    ((gfp_t)0x200u) /* Suppress page allocation failure warning */
#define __GFP_REPEAT    ((gfp_t)0x400u) /* Retry the allocation.  Might fail */
#define __GFP_NOFAIL    ((gfp_t)0x800u) /* Retry for ever.  Cannot fail */
#define __GFP_NORETRY   ((gfp_t)0x1000u)/* Do not retry.  Might fail */
#define __GFP_NO_GROW   ((gfp_t)0x2000u)/* Slab internal usage */
#define __GFP_COMP      ((gfp_t)0x4000u)/* Add compound page metadata */
#define __GFP_ZERO      ((gfp_t)0x8000u)/* Return zeroed page on success */
#define __GFP_NOMEMALLOC ((gfp_t)0x10000u) /* Don't use emergency reserves */
#define __GFP_HARDWALL   ((gfp_t)0x20000u) /* Enforce hardwall cpuset memory allocs */

/* This equals 0, but use constants in case they ever change */
#define GFP_NOWAIT      (GFP_ATOMIC & ~__GFP_HIGH)
/* GFP_ATOMIC means both !wait (__GFP_WAIT not set) and use emergency pool */
#define GFP_ATOMIC      (__GFP_HIGH)
#define GFP_NOIO        (__GFP_WAIT)
#define GFP_NOFS        (__GFP_WAIT | __GFP_IO)
#define GFP_KERNEL      (__GFP_WAIT | __GFP_IO | __GFP_FS)
#define GFP_USER        (__GFP_WAIT | __GFP_IO | __GFP_FS | __GFP_HARDWALL)
#define GFP_HIGHUSER    (__GFP_WAIT | __GFP_IO | __GFP_FS | __GFP_HARDWALL | \
                         __GFP_HIGHMEM)

/* interrupt.h */
struct tasklet_struct {
#if 0
        struct tasklet_struct *next;
        unsigned long state;
        atomic_t count;
#endif
        void (*func)(unsigned long);
        unsigned long data;
};

void tasklet_schedule(struct tasklet_struct *t);
void tasklet_init(struct tasklet_struct *t,
                         void (*func)(unsigned long), unsigned long data);

#endif /* _LINUX_MODULE_H */
