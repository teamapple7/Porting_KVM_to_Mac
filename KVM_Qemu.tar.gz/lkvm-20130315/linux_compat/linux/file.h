#ifndef _LINUX_FILE_H
#define	_LINUX_FILE_H

#include <linux/fs.h>

static inline void fput(struct linux_file *filp)
{
}

int get_unused_fd(void);
void fd_install(int fd, struct linux_file *filp);

#endif
