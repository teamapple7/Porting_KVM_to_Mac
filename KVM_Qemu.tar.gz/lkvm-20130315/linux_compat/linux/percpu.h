#ifndef _LINUX_PERCPU_H
#define _LINUX_PERCPU_H

#include <machine/param.h>

#define DEFINE_PER_CPU(type, name) \
	__typeof__(type) per_cpu__##name[MAXCPU]

#define per_cpu(var, cpu)	per_cpu__##var[cpu]

#endif
