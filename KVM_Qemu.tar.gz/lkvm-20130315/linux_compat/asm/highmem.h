#ifndef _LINUX_ASM_HIGHMEM_H
#define _LINUX_ASM_HIGHMEM_H

#include <asm/kmap_types.h>
#include <linux/interrupt.h>
#include <linux/page.h>

static inline void *kmap_atomic(struct page *page, enum km_type type)
{
	return page->__va;
}

static inline void kunmap_atomic(void *kvaddr, enum km_type type)
{
}

#endif
