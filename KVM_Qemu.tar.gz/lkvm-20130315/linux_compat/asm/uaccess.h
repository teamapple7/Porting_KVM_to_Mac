#ifndef _LINUX_UACCESS_H
#define _LINUX_UACCESS_H

#include <linux/module.h>
#include <asm/semaphore.h>

/*
 * Transfer between kernel and userspace.
 * Should really be macros because they need to compute the
 * size of *ptr to decide what to do.
 *
 * XXX must be completed.
 */
int get_user(int x, void *ptr);
int put_user(unsigned char x, void *ptr);

#endif	/* _LINUX_UACCESS_H */
