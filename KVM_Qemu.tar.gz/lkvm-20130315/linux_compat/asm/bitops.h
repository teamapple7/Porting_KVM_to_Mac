#ifndef _LINUX_ASM_BITOPS_H
#define _LINUX_ASM_BITOPS_H

#include <machine/_limits.h>

/*
 * In Linux (at least i386/amd64) this is undefined if word is zero.
 */
static inline unsigned long __ffs(unsigned long word)
{
	int i;

	for (i = 0; i < sizeof(word) * 8; i++)
		if (word & (1UL << i))
			break;

	return i;
}

/*
 * XXX this should be atomic (so it should be defined in an
 * arch-dependent way)
 */
#define	set_bit(nr, addr)	__set_bit(nr, addr)

static inline void __set_bit(int nr, volatile unsigned long *addr)
{
	addr[nr / __LONG_BIT] |= 1UL << (nr % __LONG_BIT);
}

static inline int test_bit(int nr, const volatile unsigned long *addr)
{
	return (addr[nr / __LONG_BIT] & (1UL << (nr % __LONG_BIT))) != 0;
}

static inline void clear_bit(int nr, volatile unsigned long *addr)
{
	addr[nr / __LONG_BIT] &= ~(1UL << (nr % __LONG_BIT));
}

#endif
