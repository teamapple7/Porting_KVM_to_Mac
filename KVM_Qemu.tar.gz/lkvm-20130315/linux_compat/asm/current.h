#ifndef _LINUX_CURRENT_H
#define _LINUX_CURRENT_H

/*
 * XXX should really do something better, this makes little or no
 * sense when we have more than one caller...
 */
extern struct task_struct __current;

static inline struct task_struct *get_current(void)
{
	return &__current;
}

#define	current	get_current()

#endif
