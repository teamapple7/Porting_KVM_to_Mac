#ifndef _LINUX_ASM_DESC_H
#define _LINUX_ASM_DESC_H

#include <asm/desc_defs.h>
#include <machine/cpufunc.h>
#include <machine/tss.h>

struct Xgt_desc_struct {
	unsigned short size;
	unsigned long address __attribute__((packed));
	unsigned short pad;
} __attribute__((packed));

static inline void load_TR_desc(void)
{
	int gsel_tss;

	gsel_tss = GSEL(GPROC0_SEL, SEL_KPL);
	ltr(gsel_tss);
}

#endif
