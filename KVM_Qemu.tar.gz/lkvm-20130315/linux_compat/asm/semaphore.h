#ifndef _LINUX_ASM_SEMAPHORE_H
#define _LINUX_ASM_SEMAPHORE_H

#include <sys/types.h>
#include <sys/lock.h>
#include <sys/sema.h>

/*
 * We don't know when the semaphore object is destroyed, since in
 * Linux there is no explicit call to notify this, so or we modify
 * drivers to include a destructor code, or we leak some memory.
 * We have the same problem with spinlocks.
 *
 * XXX By now just ignore that.
 */
struct semaphore {
	struct sema sema;
};

static inline void init_MUTEX(struct semaphore *sem)
{
	sema_init(&sem->sema, 1, "lkc-mutex");
}

static inline void down(struct semaphore *sem)
{
	sema_wait(&sem->sema);
}

static inline int down_interruptible(struct semaphore *sem)
{
	down(sem);
	return 0;
}

static inline void up(struct semaphore *sem)
{
	sema_post(&sem->sema);
}

#endif /* _LINUX_ASM_SEMAPHORE_H */
