#ifndef _LINUX_ASM_IO_H
#define _LINUX_ASM_IO_H

#include <linux/page.h>

#define	virt_to_phys(address)	__pa(address)

#endif
