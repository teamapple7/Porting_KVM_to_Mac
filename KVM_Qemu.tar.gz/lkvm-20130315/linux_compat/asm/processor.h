#ifndef _LINUX_ASM_PROCESSOR_H
#define _LINUX_ASM_PROCESSOR_H

#include <machine/md_var.h>
#include <sys/libkern.h>

#include <asm/msr.h>
#include <asm/segment.h>
#include <asm/system.h>
#include <asm/vm86.h>

#define	X86_EFLAGS_TF	0x00000100
#define	X86_EFLAGS_IF	0x00000200
#define	X86_EFLAGS_DF	0x00000400
#define	X86_EFLAGS_RF	0x00010000
#define	X86_EFLAGS_VM	0x00020000
#define	X86_EFLAGS_AC	0x00040000

#define	X86_VENDOR_INTEL	0
#define	X86_VENDOR_AMD		2
#define	X86_VENDOR_UNKNOWN	0xff

struct cpuinfo_x86 {
	u8 x86_vendor;
};

static inline struct cpuinfo_x86 get_boot_cpu_data(void)
{
	struct cpuinfo_x86 info;

	if (!strcmp(cpu_vendor, "GenuineIntel"))
		info.x86_vendor = X86_VENDOR_INTEL;
	else if (!strcmp(cpu_vendor, "AuthenticAMD"))
		info.x86_vendor = X86_VENDOR_AMD;
	else
		info.x86_vendor = X86_VENDOR_UNKNOWN;

	return info;
}

#define	boot_cpu_data	(get_boot_cpu_data())

static inline void cpuid(unsigned int op, unsigned int *eax,
			 unsigned int *ebx, unsigned int *ecx,
			 unsigned int *edx)
{
	__asm __volatile("cpuid"
			 : "=a" (*eax), "=b" (*ebx), "=c" (*ecx), "=d" (*edx)
			 :  "0" (op), "c" (0));
}

static inline unsigned int cpuid_ebx(unsigned int op)
{
	unsigned int r[4];

	cpuid(op, &r[0], &r[1], &r[2], &r[3]);
	return r[1];
}

static inline unsigned int cpuid_ecx(unsigned int op)
{
	unsigned int r[4];

	cpuid(op, &r[0], &r[1], &r[2], &r[3]);
	return r[2];
}

static inline void set_debugreg(int regno, unsigned long value)
{
}

struct desc_struct {
	unsigned int a, b;
};

#endif
