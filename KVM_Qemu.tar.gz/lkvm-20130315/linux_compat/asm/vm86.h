#ifndef _LINUX_ASM_VM86_H
#define _LINUX_ASM_VM86_H

#define	IOPL_MASK	0x00003000

#endif
