#ifndef _LINUX_ASM_SEGMENT_H
#define _LINUX_ASM_SEGMENT_H

#include <machine/segments.h>

#define	GDT_ENTRY_TSS	GPROC0_SEL

#define	__KERNEL_CS	GSEL(GCODE_SEL, SEL_KPL)
#define	__KERNEL_DS	GSEL(GDATA_SEL, SEL_KPL)
#define	__USER_DS	GSEL(GUDATA_SEL, SEL_UPL)

#endif
