#ifndef _LINUX_ASM_SYSTEM_H
#define _LINUX_ASM_SYSTEM_H

#include <machine/cpufunc.h>

#define	write_cr4(val)	load_cr4(val)

#define	read_cr0()	rcr0()
#define	read_cr3()	rcr3()
#define	read_cr4()	rcr4()

#endif
