#ifndef _LINUX_ASM_DESC_DEFS_H
#define _LINUX_ASM_DESC_DEFS_H

#ifdef CONFIG_X86_64

struct desc_ptr {
	unsigned short size;
	unsigned long address;
} __attribute__((packed));

#endif

#endif
