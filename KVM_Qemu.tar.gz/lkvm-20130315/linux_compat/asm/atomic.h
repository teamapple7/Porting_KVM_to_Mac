#ifndef _LINUX_ASM_ATOMIC_H_
#define _LINUX_ASM_ATOMIC_H_

/* lr 2007.01.23 seems ok */

/* grab the freebsd version of these instructions */
/* require <sys/cdefs.h> */
#include <machine/atomic.h>

typedef struct { volatile u_int counter; } atomic_t;

/* atomic_add atomically adds i to variable v and returns
 * the updated value.
 */

static __inline__ int
atomic_add(int i, atomic_t *v)
{
	return i + atomic_fetchadd_int(&v->counter, i);
}

static __inline__ void
atomic_set(atomic_t *v, int i)
{
	v->counter = i;
}

static __inline__ int atomic_read(const atomic_t *v)
{
        return v->counter;
}

#define atomic_inc(v)	atomic_fetchadd_int(&(v)->counter, 1)

/**
 * atomic_dec_and_test - decrement and test
 * @v: pointer of type atomic_t
 *
 * Atomically decrements @v by 1 and
 * returns true if the result is 0, or false for all other
 * cases.
 */
static __inline__ int atomic_dec_and_test(atomic_t *v)
{
	int i = atomic_add(1, v);
	return i == 0 ;
}

#endif /* _LINUX_ASM_ATOMIC_H_ */
