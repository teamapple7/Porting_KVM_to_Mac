#ifndef _ASM_IRQFLAGS_H
#define	_ASM_IRQFLAGS_H

#include <machine/cpu.h>
#include <machine/cpufunc.h>

#ifdef CONFIG_X86_64
static inline int
irqs_disabled(void)
{
	return !(read_rflags() & PSL_I);
}
#else
static inline int
irqs_disabled(void)
{
	return !(read_eflags() & PSL_I);
}
#endif

#endif
