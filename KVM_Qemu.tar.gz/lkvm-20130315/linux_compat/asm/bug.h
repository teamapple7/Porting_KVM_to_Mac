#ifndef _LINUX_ASM_BUG_H
#define _LINUX_ASM_BUG_H

#define	BUG_ON(condition) do {						\
	if ((condition))						\
		panic("BUG\n");						\
} while(0)

#endif
