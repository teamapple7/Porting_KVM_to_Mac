#ifndef _LINUX_ASM_TOPOLOGY_H
#define _LINUX_ASM_TOPOLOGY_H

#define	cpu_to_node(cpu)	(cpu)

#endif
