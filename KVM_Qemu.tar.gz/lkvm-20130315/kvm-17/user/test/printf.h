
int printf(const char *fmt, ...);
