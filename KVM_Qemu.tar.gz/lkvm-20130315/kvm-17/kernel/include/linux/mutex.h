/*
 * Empty file to satisfy #include <linux/mutex.h> for older kernels.
 */


